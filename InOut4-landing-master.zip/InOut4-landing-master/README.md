# InOut: India's biggest community hackathon
Landing page of InOut 4 [WIP]


## How to run:

1. Clone the repo.
2. Run `yarn` or `npm install`.
3. Run `gulp build` to build locally. Check `public` directory for the files.
4. Run `gulp` to watch.
